// pages/viewbox/viewbox.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url:'',
    imageurl:'',
    navbar: ['视频', '文章'],
    currentTab: 0 
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var that = this;
    console.log('页面加载');
    wx.request({
      url: app.globalData.path + 'getview.php',
      success: function (res) {
        console.log(res.data);
        that.setData({
          url: res.data.viewbox,
          imageurl:res.data.imoprtinfo
        })
      }
    })
  },
 onShow:function(){
   var that = this;
   console.log('页面加载');
   wx.request({
     url: app.globalData.path + 'getview.php',
     success: function (res) {
       console.log(res.data);
       that.setData({
         url: res.data.viewbox,
         imageurl: res.data.imoprtinfo
       })
     }
   })
 },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  selectview: function(e){
    console.log("发生视频选择时间");
    console.log(e.currentTarget.id);
    var url = e.currentTarget.id;
    wx.navigateTo({
      url: "view?id="+url
    })
  },
  
  navbarTap: function (e) {
    this.setData({
      currentTab: e.currentTarget.dataset.idx
    })
  } 
})